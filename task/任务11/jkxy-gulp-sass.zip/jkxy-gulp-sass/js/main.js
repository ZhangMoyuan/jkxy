define(function(require, exports, module) {
	require('jquery-1.11.0');
	var topSearch = require("topSearch");	//顶部搜索框
	var lessionClassFiy =require("lessionClassFiy");	//左侧课程列表
	var nav = require("nav");	//导航
	var recommend =require("recommend");
	var hotLessionTab =require("hotLessionTab");   //热门课程切换
	var projectPath = require("projectPath");
	var mapbox = require("mapbox");
	var wiki = require("wiki");		//wiki
	var enterprise = require("enterprise");
	var university = require("university");	//大学列表轮播图
	var banner = require("banner");		//banner轮播图
	
});